<?php
/**
 * Copyright © 2021 Euronet. All rights reserved.
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Smartweb_Auto',
    __DIR__
);
